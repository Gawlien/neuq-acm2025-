#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T,class TT=null_type>
using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int n;cin>>n;
    vector<int>rec;
    vector<int>win;

    if(n==1)
    {
        cout<<"?"<<' '<<1<<' '<<2<<'\n';
        cout.flush();
        int x;cin>>x;
        if(x==1)
        {
            cout<<"!"<<' '<<1<<'\n';
            cout.flush();
        }
        else
        {
            cout<<"!"<<' '<<2<<'\n';
            cout.flush();
        }
        return;
    }

    for(int i=1;i<=pow(2,n);i++)
    {
        win.pb(i);
    }

    int cnt=0;
    while(SZ(win)>4)
    {
        vector<int>now;
        for(int i=0;i<SZ(win);i++)
        {
            rec.pb(win[i]);
            cnt++;
            if(cnt==4)
            {
                cnt=0;
                cout<<"?"<<' '<<rec[0]<<' '<<rec[2]<<'\n';
                cout.flush();
                int x;cin>>x;
                if(x==0)
                {
                    cout<<"?"<<' '<<rec[1]<<' '<<rec[3]<<'\n';
                    cout.flush();
                    int y;cin>>y;
                    if(y==1)now.pb(rec[1]);
                    else now.pb(rec[3]);
                }
                else if(x==1)
                {
                    cout<<"?"<<' '<<rec[0]<<' '<<rec[3]<<'\n';
                    cout.flush();
                    int y;cin>>y;
                    if(y==1)now.pb(rec[0]);
                    else now.pb(rec[3]);
                }
                else if(x==2)
                {
                    cout<<"?"<<' '<<rec[1]<<' '<<rec[2]<<'\n';
                    cout.flush();
                    int y;cin>>y;
                    if(y==1)now.pb(rec[1]);
                    else now.pb(rec[2]);
                }
                rec.clear();
            }
        }
        win=now;
    }

    if(SZ(win)==2)
    {
        cout<<"?"<<' '<<win[0]<<' '<<win[1]<<'\n';
        cout.flush();
        int y;cin>>y;
        if(y==1)
        {
            cout<<"!"<<' '<<win[0]<<'\n';
            cout.flush();
        }
        else 
        {
            cout<<"!"<<' '<<win[1]<<'\n';
            cout.flush();
        }
    }
    else if(SZ(win)==4)
    {
        cout<<"?"<<' '<<win[0]<<' '<<win[2]<<'\n';
        cout.flush();
        int x;cin>>x;
        if(x==0)
        {
            cout<<"?"<<' '<<win[1]<<' '<<win[3]<<'\n';
            cout.flush();
            int y;cin>>y;
            if(y==1)
            {
                cout<<"!"<<' '<<win[1]<<'\n';
                cout.flush();
            }
            else 
            {
                cout<<"!"<<' '<<win[3]<<'\n';
                cout.flush();
            }
        }
        else if(x==1)
        {
            cout<<"?"<<' '<<win[0]<<' '<<win[3]<<'\n';
            cout.flush();
            int y;cin>>y;
            if(y==1)
            {
                cout<<"!"<<' '<<win[0]<<'\n';
                cout.flush();
            }
            else 
            {
                cout<<"!"<<' '<<win[3]<<'\n';
                cout.flush();
            }
        }
        else if(x==2)
        {
            cout<<"?"<<' '<<win[1]<<' '<<win[2]<<'\n';
            cout.flush();
            int y;cin>>y;
            if(y==1)
            {
                cout<<"!"<<' '<<win[1]<<'\n';
                cout.flush();
            }
            else 
            {
                cout<<"!"<<' '<<win[2]<<'\n';
                cout.flush();
            }
        }
    }
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}
