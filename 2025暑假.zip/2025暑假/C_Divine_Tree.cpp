#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int n,m;cin>>n>>m;
    vector<int>vis(n+1,0);
    int mn=n,mx=n*(n+1)/2;
    if(m<mn||m>mx){cout<<-1<<'\n';return;}
    if(m==n)
    {
        cout<<1<<'\n';
        for(int i=1;i<n;i++)cout<<i<<' '<<i+1<<'\n';
        return;
    }

    int f=-1;
    vector<int>qz(n+1,0);
    qz[0]=0;
    for(int i=1;i<=n;i++)
    {
        qz[i]=qz[i-1]+(n-i+1);
    }
    int id=-1;
    int num=0;
    auto chk=[&](int x)->bool
    {
        if(x==1)
        {
            f=1;
            return false;
        }
        int c=qz[x-2]+(n-x+1);
        if(m<=c+1)
        {
            f=0;
            return false;
        }
        else if(m>qz[x-1]+(n-x+1))
        {
            f=1;
            return false;
        }
        else 
        {
            num=m-c;
            id=x;
            return true;
        }
    };
    int l=1,r=n;
    while(l<=r)
    {
        int mid=l+r>>1;
        f=-1;
        if(chk(mid))
        {
            break;
        }
        else if(f==1)l=mid+1;
        else if(f==0)r=mid-1;
        bug(f,l,r);
    }
    vector<int>v;
    bug(id,num);
    if(id==2)
    {
        cout<<num<<'\n';
        v.pb(num);
        for(int i=1;i<=n;i++)
        {
            if(i==num)continue;
            else v.pb(i);
        }
        for(int i=0;i<SZ(v)-1;i++)cout<<v[i]<<' '<<v[i+1]<<'\n';
        return;
    }
    else 
    {
        cout<<n<<'\n';
        for(int i=1;i<=id-2;i++)
        {
            vis[n-i+1]=1;
            v.pb(n-i+1);
        }
        v.pb(num);
        vis[num]=1;
        for(int i=1;i<=n;i++)
        {
            if(vis[i])continue;
            else v.pb(i);
        }
        for(int i=0;i<SZ(v)-1;i++)cout<<v[i]<<' '<<v[i+1]<<'\n';
        return;
    }
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}