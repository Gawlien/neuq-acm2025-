#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

const int inf=1E9;
void solve()
{
    int n;cin>>n;
    vector<int>A(n+1),D(n+1);
    rep(i,1,n)cin>>A[i];
    rep(i,1,n)cin>>D[i];

    auto chk=[&](int x)-> bool
    {
        int mn1=inf;
        int mn2=inf;
        int id=-1;
        vector<int>a(A);
        vector<int>d(D);
        for(int i=1;i<=x;i++)
        {
            if(a[i]<mn1)id=i;
            mn1=min(a[i],mn1);
        }
        for(int i=1;i<=n-x+1;i++)
        {
            mn2=min(mn2,d[i]);
        }
        if(mn1>mn2)return true;
        int id2=-1;
        int mx=-1;
        //bug(id);
        for(int i=x+1;i<=n;i++)
        {
            if(a[i]>mx)
            {
                mx=a[i];
                id2=i;
            }
        }
        if(id2==-1)return false;
        bug(id,id2,x);
        swap(a[id],a[id2]);
        mn1=inf,mn2=inf;
        for(int i=1;i<=x;i++)
        {
            //if(a[i]<mn1)id=i;
            mn1=min(a[i],mn1);
        }
        for(int i=1;i<=n-x+1;i++)
        {
            mn2=min(mn2,d[i]);
        }
        if(mn1>mn2)return true;
        else return false;
    };
    int ans=0;
    int l=0,r=n;
    while(l<=r)
    {
        int mid=l+r>>1;
        if(chk(mid))
        {
            bug(mid);
            ans=mid;l=mid+1;
        }
        else r=mid-1;
    }
    cout<<ans<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}