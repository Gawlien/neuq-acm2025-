#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

const int N=5E5+10;
int dp[N];

void init()
{
    memset(dp,0x3f,sizeof(dp));
    dp[1]=1;
    for(int i=3;i<N;i+=2)
    {
        dp[i]=min(dp[i-2]+1,dp[i]);
        for(int j=3;j*j<=i;j+=2)
        {
            if(i%j==0)dp[i]=min(dp[j]+dp[i/j]-1,dp[i]);
        }
    }
}

void solve()
{
    int m;cin>>m;
    if(m%2==0){cout<<-1<<'\n';return;}
    cout<<dp[m]<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    init();
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}