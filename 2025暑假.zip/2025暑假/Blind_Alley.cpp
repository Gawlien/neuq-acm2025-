#include <bits/stdc++.h>
#include <bits/extc++.h>
using namespace std;
using namespace __gnu_pbds;
#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else
#include "debug.h"
#endif
#define int long long
#define pii pair<int,int>
#define pb emplace_back
template<class T1,class T2=null_type,class T3=less<T1>>
using ordered_set=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;
template<class...T>void out(const T&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}
const int N=1e6+3,inf=2e18,mod=998244353;
vector<vector<char>>a;
vector<vector<bool>>vis,rea;
vector<vector<int>>c;
int mx[N],mn[N];
int cnt,n,m;
int dx[]={1,-1,0},dy[]={0,0,-1};
int dx1[]={1,-1,0},dy1[]={0,0,1};
bool ok[N];
void dfs(int x,int y){
    if(vis[x][y]||a[x][y]=='1')return;
    vis[x][y]=1;
    c[x][y]=cnt;
    mx[cnt]=max(mx[cnt],y);
    mn[cnt]=min(mn[cnt],y);
    for(int i=0;i<3;i++){
        int ex=x+dx[i],ey=y+dy[i];
        if(1<=ex&&ex<=n&&1<=ey&&ey<=m)dfs(ex,ey);
    }
}
void dfs1(int x,int y){
    if(rea[x][y]||a[x][y]=='1')return;
    rea[x][y]=1;
    for(int i=0;i<3;i++){
        int ex=x+dx1[i],ey=y+dy1[i];
        if(1<=ex&&ex<=n&&1<=ey&&ey<=m)dfs1(ex,ey);
    }
}
void solve(){
    int k;cin>>n>>m>>k;
    cnt=0;
    a=vector<vector<char>>(n+1,vector<char>(m+1));
    c=vector<vector<int>>(n+1,vector<int>(m+1));
    rea=vis=vector<vector<bool>>(n+1,vector<bool>(m+1,0));
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            cin>>a[i][j];
        }
    }
    dfs1(1,1);
    for(int i=m;i;i--){
        for(int j=1;j<=n;j++){
            if(vis[j][i]||a[j][i]=='1')continue;
            cnt++;
            mx[cnt]=0;
            mn[cnt]=inf;
            ok[cnt]=rea[j][i];
            dfs(j,i);
        }
    }
    // for(int i=1;i<=n;i++){
    //     for(int j=1;j<=m;j++){
    //         cout<<rea[i][j];
    //     }
    //     cout<<'\n';
    // }
    for(int i=2;i<=cnt;i++){
        if(ok[i]&&mx[i]-mn[i]>=k-1){out("Yes");return;}
    }
    out("No");
}
signed main(){
    ios::sync_with_stdio(0);cin.tie(0);
    int t;cin>>t;
    while(t--)solve();
    return 0;
}