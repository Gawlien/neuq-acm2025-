#ifndef DEBUG_H
// ====================== 核心打印函数 ======================
namespace debug_impl {
    // 声明打印函数（递归基础）
    template <typename T>
    void __print(const T& x);

    // 基本类型打印重载
    void __print(char x) { cout << '\'' << x << '\''; }
    void __print(const char* x) { cout << '\"' << x << '\"'; }
    void __print(const string& x) { cout << '\"' << x << '\"'; }
    void __print(bool x) { cout << (x ? "true" : "false"); }

    // 🔥 关键修改：添加 vector<bool>::reference 的特化处理
    // std::vector<bool> 元素访问返回代理对象而非 bool&
    void __print(const vector<bool>::reference& x) {
        __print(static_cast<bool>(x)); // 转换为 bool 后调用基础打印
    }

    // 递归打印pair
    template <typename T, typename V>
    void __print(const pair<T, V>& x) {
        cout << '{';
        __print(x.first);
        cout << ',';
        __print(x.second);
        cout << '}';
    }

    // 通用容器打印模板（使用 std::begin/end）
    template <typename T>
    void __print_container(const T& v) {
        cout << '{';
        auto it_begin = begin(v);
        auto it_end = end(v);
        for (auto it = it_begin; it != it_end; ++it) {
            if (it != it_begin) cout << ',';
            __print(*it);  // 依赖已添加的代理对象重载
        }
        cout << '}';
    }

    // 静态数组打印特化
    template <typename T, size_t N>
    void __print(const T (&arr)[N]) {
        cout << '{';
        for (size_t i = 0; i < N; ++i) {
            if (i > 0) cout << ',';
            __print(arr[i]);
        }
        cout << '}';
    }

    // 元组打印辅助函数
    template <typename Tuple, size_t... Is>
    void __print_tuple_helper(const Tuple& t, index_sequence<Is...>) {
        cout << '{';
        (( (Is > 0) && (cout << ","), __print(get<Is>(t)) ), ...);
        cout << '}';
    }
    template <typename... Args>
    void __print(const tuple<Args...>& t) {
        __print_tuple_helper(t, make_index_sequence<sizeof...(Args)>());
    }

    // 调试输出入口
    template <typename T>
    void __print(const T& x) {
        if constexpr (is_fundamental_v<T> || is_convertible_v<T, string>) {
            cout << x;
        } else {
            __print_container(x);
        }
    }

    // 参数包展开
    void __print_multi() {}
    template <typename T, typename... Args>
    void __print_multi(const T& first, const Args&... rest) {
        __print(first);
        if constexpr (sizeof...(rest) > 0) {
            cout << ' ';
            __print_multi(rest...);
        }
    }

    // 调试宏实现
    template <typename... Args>
    void bug(const Args&... args) {
        cout << "DEBUG ";
        __print_multi(args...);
        cout << endl;
    }
} // namespace debug_impl
#define bug(...) debug_impl::bug(__VA_ARGS__)
#endif // DEBUG_H