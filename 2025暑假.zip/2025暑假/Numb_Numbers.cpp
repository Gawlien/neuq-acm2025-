// #include<bits/stdc++.h>
// #include<bits/extc++.h>

// using namespace std;
// using namespace __gnu_pbds;

// #define int long long
// #define pb(x) push_back(x)
// #define ppb pop_back()
// #define fi first 
// #define se second 
// #define mkp make_pair
// #define SZ(x) ((int)((x).size()))
// #define lb(x) ((x) & (-(x)))
// #define bp(x) __builtin_popcount(x)
// #define bc(x) __builtin_ctzll(x)
// #define rep(i,a,b) for(int i=a;i<=b;i++)
// #define rep_(i,a,b) for(int i=a;i>=b;i--)
// #define umap gp_hash_table
// typedef pair<int,int> pii;
// const int mod=1E9+7;
// const int inf=1E18;
// int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
// int gcd(int a,int b) { return b?gcd(b,a%b):a;}

// #ifdef ONLINE_JUDGE
// #define bug(...) void(0)
// #else 
// template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
// #endif
// template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

// template <class T1,class T2> 
// struct hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{hash<T1>H1;hash<T2>H2;return H1(x.first)^H2(x.second);}};

// const int N=2E5+10;
// int a[N];

// void solve()
// {
//     int n,q;cin>>n>>q;
//     map<int,int>mp;
//     int ans=0;

//     for(int i=1;i<=n;i++)
//     {
//         cin>>a[i];
//         mp[a[i]]++;
//     }

//     auto it=mp.begin();
//     for(;it!=mp.end()&&n-ans-(it->se)>=n/2;it++)
//     {
//         ans+=it->se;
//     }

//     while(q--)
//     {
//         int p,v;cin>>p>>v;
//         //bug("*");
//         if(a[p]<(it->fi))ans--;
//         mp[a[p]]--;
//         a[p]+=v;
//         mp[a[p]]++;
//         if(a[p]<(it->fi))ans++;
//         for(;it!=mp.end()&&n-ans-(it->se)>=n/2;it++)ans+=(it->se);

//         cout<<ans<<'\n';
//     }
// }
// signed main()
// {
//     ios::sync_with_stdio(false);cin.tie(nullptr);
//     int tt;cin>>tt;while(tt--)solve();
//     return 0;
// }

#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=1E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T,class TT=null_type>
using rbt=tree<T,TT,greater<T>,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

const int N=2E5+10;
int a[N];

void solve()
{
    int n,q;cin>>n>>q;
    umap<int,int>mp;
    int ans=0;
    rbt<pii>s;

    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        s.insert({a[i],++mp[a[i]]});
    }

    while(q--)
    {
        int op,v;cin>>op>>v;
        
        s.erase({a[op],mp[a[op]]--});
        s.insert({a[op]+v,++mp[a[op]+v]});
        a[op]+=v;
        auto it=s.find_by_order(n/2);
        int c=it->fi;
        if(it->se!=mp[c]){bug("*");int x=s.upper_bound({c,0})->fi;cout<<SZ(s)-s.order_of_key({x,mp[x]})<<'\n';}
        else cout<<SZ(s)-s.order_of_key({c,mp[c]})<<'\n';
        bug(c);
        
    }
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}