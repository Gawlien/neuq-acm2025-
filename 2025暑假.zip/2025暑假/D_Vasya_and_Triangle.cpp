#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int n,m,k;cin>>n>>m>>k;

    if((2*n*m)%k!=0){cout<<"NO"<<'\n';return;}
    else cout<<"YES"<<'\n';

    int s=2*n*m/k;
    cout<<0<<' '<<0<<'\n';
    vector<int>N,M;
    for(int i=2;i*i<=n;i++)
    {
        if(n%i==0)
        {
            N.pb(i);
            N.pb(n/i);
        }
    }
    for(int i=2;i*i<=m;i++)
    {
        if(m%i==0)
        {
            M.pb(i);
            M.pb(m/i);
        }
    }
    N.pb(1);
    N.pb(n);
    M.pb(1);
    M.pb(m);
    //for(auto c:N)bug(c);
    sort(N.begin(),N.end());
    sort(M.begin(),M.end());
    int f=0;
    for(int i=SZ(N)-1;i>=0;i--)
    {
        if(s%N[i]==0)
        {
            if(N[i]<=n&&(s/N[i])<=m)
            {
                f=1;
                cout<<N[i]<<' '<<0<<'\n';
                cout<<0<<' '<<s/N[i]<<'\n';
                break;
            }
            else if(N[i]<=m&&(s/N[i])<=n)
            {
                cout<<s/N[i]<<' '<<0<<'\n';
                cout<<0<<' '<<N[i]<<'\n';
                f=1;
                break;
            }
            else break;
        }
    }
    if(!f)
    {
        for(int i=SZ(M)-1;i>=0;i--)
        {
            if(s%M[i]==0)
            {
                if(M[i]<=n&&s/M[i]<=m)
                {
                    cout<<M[i]<<' '<<0<<'\n';
                    cout<<0<<' '<<s/M[i]<<'\n';
                    return;
                }
                else if(M[i]<=m&&s/M[i]<=n)
                {
                    cout<<s/M[i]<<' '<<0<<'\n';
                    cout<<0<<' '<<M[i]<<'\n';
                    return;
                }
                return;
            }
        }
    }
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    solve();
    return 0;
}