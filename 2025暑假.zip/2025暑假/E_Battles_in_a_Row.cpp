#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int n,h,m;cin>>n>>h>>m;
    vector<int>a(n+1),b(n+1);
    rep(i,1,n)cin>>a[i]>>b[i];

    int ans=0;
    int l=0,r=n;

    auto chk=[&](int mid)->bool
    {
        int x=h,y=m;
        for(int i=1;i<=mid;i++)
        {
            if(x<0&&y<0)return false;
            if(a[i]>b[i])
            {
                if(y>=b[i])y-=b[i];
                else x-=a[i];
            }
            else 
            {
                if(x>=a[i])x-=a[i];
                else y-=b[i];
            }
        }
        if(x<0||y<0)return false;
        return true;
    };
    while(l<=r)
    {
        int mid=l+r>>1;
        if(chk(mid))
        {
            ans=mid;
            l=mid+1;
        }
        else r=mid-1;
    }
    cout<<ans<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    solve();
    return 0;
}