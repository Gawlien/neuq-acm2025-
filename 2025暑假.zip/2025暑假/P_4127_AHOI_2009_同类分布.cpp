#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T,class TT=null_type>
using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

int dp[20][200][200];
int a[20];
int Mod;
int len;

int dfs(int pos,int sum,int now,int lim)
{
    if(pos<1&&sum==0)return 0;
    if(pos<1){return now==0&&sum==Mod ?1:0;}
    if(!lim&&dp[pos][sum][now]!=-1)return dp[pos][sum][now];
    int rec=0;
    int res=lim ?a[pos]:9;
    for(int i=0;i<=res;i++)
    {
        rec+=dfs(pos-1,(sum+i),(now*10LL+i)%Mod,lim&&(i==res));
    }
    if(!lim)dp[pos][sum][now]=rec;
    return rec;
}
int f(int x)
{
    len=0;
    while(x)
    {
        a[++len]=x%10;
        x/=10;
    }
    
    int ret=0;
    for(Mod=1;Mod<=9*len;Mod++)
    {
        memset(dp,-1,sizeof(dp));
        ret+=dfs(len,0,0,1);
    }
    return ret;
}
void solve()
{
    int l,r;cin>>l>>r;
    cout<<f(r)-f(l-1)<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    solve();
    return 0;
}




// #include<bits/stdc++.h>
// using namespace std;
// typedef long long ll;
// ll l,r,dp[20][200][200];
// int len,a[20],mod;
// ll dfs(int pos,int sum,ll st,int limit)
// {
// 	if(pos>len&&sum==0) return 0;
// 	if(pos>len) return st==0&&sum==mod?1:0;
// 	if(!limit&&dp[pos][sum][st]!=-1) return dp[pos][sum][st];
// 	ll ret=0;
// 	int res=limit?a[len-pos+1]:9;
// 	for(int i=0;i<=res;i++)
// 		ret+=dfs(pos+1,sum+i,(10ll*st+i)%mod,i==res&&limit);
// 	return limit?ret:dp[pos][sum][st]=ret;
// }
// ll part(ll x)
// {
// 	len=0;
// 	while(x) a[++len]=x%10,x/=10;
// 	ll ret=0;
// 	for(mod=1;mod<=9*len;mod++)//枚举模数（就是各位数之和）
// 	{
// 		memset(dp,-1,sizeof dp);
// 	    ret+=dfs(1,0,0,1);
// 	}
// 	return ret;
// }
// int main()
// {
//     scanf("%lld%lld",&l,&r);
//     printf("%lld\n",part(r)-part(l-1));
// 	return 0;
// }