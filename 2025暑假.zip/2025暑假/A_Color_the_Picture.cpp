#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T,class TT=null_type>
using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int n,m,k;cin>>n>>m>>k;
    vector<int>a(k+1);
    bool ok=false;
    for(int i=1;i<=k;i++)
    {
        cin>>a[i];
        if(a[i]>=m*n)ok=true;
    }

    if(ok){cout<<"Yes"<<'\n';return;}
    //int num=bp(a[1]);

    int c1=0,c2=0;
    int f1=1,f2=1;
    int more=0;
    for(int i=1;i<=k;i++)
    {
        int cnt=(a[i]/n);
        more+=max(0LL, cnt-2);
        if(cnt<=1)continue;
        else 
        {
            if(c1+2>m)
            {
                if(more>=m-c1)f1=1;
                else f1=0;
            }
            else c1+=2;
        }
    }
    if(c1+more<m)f1=0;

    more=0;
    for(int i=1;i<=k;i++)
    {
        int cnt=(a[i]/m);
        more+=max(0LL,cnt-2);
        if(cnt<=1)continue;
        else 
        {
            if(c2+2>n)
            {
                if(more>=n-c2)f2=1;
                else f2=0;
            }
            else c2+=2;
        }
    }
    if(c2+more<n)f2=0;

    if(f1||f2){cout<<"Yes"<<'\n';}
    else cout<<"No"<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}
