#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=998244353;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

const int N=1e5+3;
int f[N],inv[N];

auto init=[](){
    f[0]=1;
    for(int i=1;i<N;i++)f[i]=f[i-1]*i%mod;
    inv[N-1]=fpw(f[N-1],mod-2);
    for(int i=N-1;i;i--)inv[i-1]=inv[i]*i%mod;
    return 0;
}();
int comb(int n,int m){
    if(m>n)return 0;
    if(m<0)return 0;
    return f[n]*inv[m]%mod*inv[n-m]%mod;
}


vector<int>yin[N+1];
int dp[N+1][130];

void yu(int N)
{
    for(int i=1;i<N;i++)
    {
        for(int j=2;i*j<N;j++)
        {
            yin[i*j].pb(i);
        }
    }
    dp[1][1]=1;
    for(int i=1;i<=N;i++)
    dp[i][0]=1;
    //int bdp=0;
    for(int i=2;i<=N;i++)
    {
        dp[i][1]=1;
        for(int j=0;j<yin[i].size();j++)
        for(int len=1;len<=yin[i].size();len++)
        {
            dp[i][len+1]=(dp[i][len+1]+dp[yin[i][j]][len])%mod;
            //bdp=max(bdp,len);
        }
        
    }
    // cout<<bdp<<" ";
    // exit(0);
}

void solve()
{
    int m,n;cin>>m>>n;
    if(n==1){cout<<0;return;}
    int all=(n*comb(m,n))%mod;
    int ans=0;
    for(int i=1;i<=m;i++)
    {
        for(int j=1;j<=20;j++)
        {
            int b=n-j;
            int cnt=comb(m/i-1,b)%mod;
            //if(cnt==0)cnt=1;
            ans=(ans+(cnt*dp[i][j])%mod)%mod;
            //bug(i,j,ans);
            //cout<<"***"<<i<<' '<<j<<" "<<ans<<'\n';
        }
    }
    bug(all,ans);
    cout<<((all-ans)%mod+mod)%mod<<'\n';
    bug(dp[1][3]);
    // cout<<"***"<<dp[8][2]<<'\n';
    //if(!ok)out("error");
}
signed main()
{
    yu(N);
    ios::sync_with_stdio(false);cin.tie(nullptr);
    solve();
    return 0;
}