#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int n,s,x;cin>>n>>s>>x;
    vector<int>a(n+1);
    rep(i,1,n)cin>>a[i];

    int ans=0;

    auto f=[&](vector<int> &b)->int 
    {
        map<int,int>cnt;
        int ret=0;
        int n=SZ(b);
        vector<int>qz(n,0);
        for(int i=0;i<n;i++)
        {
            qz[i]=b[i]+(i? qz[i-1]:0);
        }
        for(int i=0;i<n;i++)cnt[qz[i]]++;
        int head=0;
        for(int i=0;i<n;i++)
        {
            while(head<i||(head<n&&b[head]<x))
            {
                cnt[qz[head]]--;
                head++;
            }
            ret+=(cnt[(i?qz[i-1]:0) +s]);
        }
        return ret;
    };
    for(int i=1;i<=n;)
    {
        if(a[i]>x)
        {
            i++;
            continue;
        }
        int id=i;
        while(id<=n&&a[id]<=x)
        {
            id++;
        }
        vector<int>b(a.begin()+i,a.begin()+id);
        ans+=f(b);
        i=id;
    }
    cout<<ans<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}