// #include<bits/stdc++.h>
// #include<bits/extc++.h>

// using namespace std;
// using namespace __gnu_pbds;

// #define int long long
// #define pb(x) push_back(x)
// #define ppb pop_back()
// #define fi first 
// #define se second 
// #define mkp make_pair
// #define SZ(x) ((int)((x).size()))
// #define lb(x) ((x) & (-(x)))
// #define bp(x) __builtin_popcount(x)
// #define bc(x) __builtin_ctzll(x)
// #define rep(i,a,b) for(int i=a;i<=b;i++)
// #define rep_(i,a,b) for(int i=a;i>=b;i--)
// #define umap gp_hash_table
// typedef pair<int,int> pii;
// const int mod=1E9+7;
// const int inf=2E18;
// int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
// int gcd(int a,int b) { return b?gcd(b,a%b):a;}

// template <class T1,class T2> 
// struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

// template<class T,class TT=null_type>
// using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

// #ifdef ONLINE_JUDGE
// #define bug(...) void(0)
// #else 
// template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
// #endif
// template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

// void solve()
// {
    
// }
// signed main()
// {
//     ios::sync_with_stdio(false);cin.tie(nullptr);
//     int tt;cin>>tt;while(tt--)solve();
//     return 0;
// }

#include <iostream>
#include <vector>
using namespace std;

const int MOD = 998244353;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t;
    cin >> t;
    while (t--) {
        int n, k;
        cin >> n >> k;
        
        vector<int> a(n + 2, 0);  // 1-based indexing
        vector<int> b(n + 2, 0);
        
        for (int j = 1; j <= n; ++j) {
            cin >> a[j];
        }
        for (int j = 1; j <= n; ++j) {
            cin >> b[j];
        }
        
        vector<int> ways(n + 2, 0);    // 每列的总填充方式
        vector<int> a_ge_b(n + 2, 0);  // a >= b 的填充方式
        vector<int> b_ge_a(n + 2, 0);  // b >= a 的填充方式
        
        // 预处理每列的信息
        for (int j = 1; j <= n; ++j) {
            if (a[j] != -1 && b[j] != -1) {
                // 两个都固定
                ways[j] = 1;
                a_ge_b[j] = (a[j] >= b[j]) ? 1 : 0;
                b_ge_a[j] = (b[j] >= a[j]) ? 1 : 0;
            } else if (a[j] != -1) {
                // a固定，b可变
                int fixed_a = a[j];
                ways[j] = k;
                a_ge_b[j] = fixed_a;  // b can be 1..fixed_a
                b_ge_a[j] = k - fixed_a + 1;  // b can be fixed_a..k
            } else if (b[j] != -1) {
                // b固定，a可变
                int fixed_b = b[j];
                ways[j] = k;
                a_ge_b[j] = k - fixed_b + 1;  // a can be fixed_b..k
                b_ge_a[j] = fixed_b;  // a can be 1..fixed_b
            } else {
                // 两个都可变
                ways[j] = k * k;
                a_ge_b[j] = k * (k + 1) / 2;
                b_ge_a[j] = k * (k + 1) / 2;
            }
        }
        
        // 动态规划初始化
        vector<vector<int>> dp(n + 2, vector<int>(2, 0));
        dp[1][0] = a_ge_b[1];
        dp[1][1] = b_ge_a[1];
        
        // 动态规划转移
        for (int j = 2; j <= n; ++j) {
            // 状态0: a[j] >= b[j]
            dp[j][0] = (1LL * dp[j-1][0] * a_ge_b[j]) % MOD;
            
            // 状态1: b[j] >= a[j]
            dp[j][1] = (1LL * dp[j-1][1] * b_ge_a[j]) % MOD;
        }
        
        // 答案为最后一列两种状态的和
        int ans = (dp[n][0] + dp[n][1]) % MOD;
        cout << ans << "\n";
    }
    
    return 0;
}