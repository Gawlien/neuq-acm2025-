#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T,class TT=null_type>
using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int n;cin>>n;
    vector<int>ans;
    int l=n/3;
    int r=(2*n+2)/3;
    bug(l,r);

    auto chk=[&](int x)->bool 
    {
        if(x==0)return false;
        if(x==1)return false;
        for(int i=2;i*i<=x;i++)
        {
            if(x%i==0)return false;
        }
        return true;
    };

    int p=-1;
    for(int i=l;i<=r;i++)
    {
        if(chk(i)){p=i;break;}
    }

    umap<int,int>mp;

    cout<<p<<' ';
    mp[p]=1;
    for(int i=1;;i++)
    {
        if(i&1)
        {
            if(p-(i+1)/2>0)
            {
                cout<<p-(i+1)/2<<' ';
                mp[p-(i+1)/2]=1;
            }
            else break;
        }
        else 
        {
            if(p+i/2<=n)
            {
                cout<<p+i/2<<' ';
                mp[p+i/2]=1;
            }
            else break;
        }
    }
    for(int i=1;i<=n;i++)
    {
        if(mp[i]!=1)cout<<i<<' ';
    }
    cout<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}
