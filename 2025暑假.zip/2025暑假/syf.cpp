#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=2e5+10;
int T,n,a,b,c,aa,bb,cc,ans[N],cnt;
void init()
{
    cnt=0;
}
void solve()
{
    cin>>a>>b>>c;
    init();
    aa=__lg(a),bb=__lg(b),cc=__lg(c);
    if(a==0&&b==0&&c!=0) {cout<<-1<<endl; return ;}
    if(a==0&&b==0&&c==0) {cout<<0<<endl<<endl;}
    if(a==0)
    {
        ans[++cnt]=3;
        a=a^b;
        aa=bb;
    }
    if(b==0)
    {
        ans[++cnt]=4;
        b=b^a;
        bb=aa;
    }
    if(c==0)
    {
        while(bb>=0)
        {
            ans[++cnt]=2;
            bb--;
        }
        b=0;
        ans[++cnt]=4;
        b=b^a;
        bb=aa;
        ans[++cnt]=3;
        a=0;
        while(bb>=0)
        {
            ans[++cnt]=2;
            bb--;
        }
        cout<<cnt<<endl;
        for(int i=1;i<=cnt;i++)
        cout<<ans[i]<<" ";
        return ;
    }
    if(aa<cc)
    {
        while(aa<cc)
        {
            ans[++cnt]=1;
            a<<=1;
            aa++;
        }
        if(bb>aa-1)
        {
            while(bb>aa-1)
            {
                ans[++cnt]=2;
                b>>=1;
                bb--;
            }
        }
        else if(bb<aa-1)
        {
            ans[++cnt]=4;
            b=b^a;
            ans[++cnt]=2;
            b>>=1;
            bb=aa-1;
        }
    }
    else if(aa==cc)
    {
        if(bb>aa-1)
        {
            while(bb>aa-1)
            {
                ans[++cnt]=2;
                b>>=1;
                bb--;
            }
        }
        else if(bb<aa-1)
        {
            ans[++cnt]=4;
            b=b^a;
            ans[++cnt]=2;
            b>>=1;
            bb=aa-1;
        }
    }
    else if(aa>cc)
    {
        if(bb>cc)
        {
            while(bb>cc)
            {
                ans[++cnt]=2;
                b>>=1;
                bb--;
            }
        }
        else if(bb<cc)
        {
            ans[++cnt]=4;
            b=b^a;
            bb=aa;
            while(bb>cc)
            {
                ans[++cnt]=2;
                b>>=1;
                bb--;
            }
        }
        ans[++cnt]=4;
        b=b^a;
        ans[++cnt]=3;
        a=a^b;
        aa=__lg(a),bb=__lg(b);
        while(aa<cc)
        {
            ans[++cnt]=1;
            a<<=1;
            aa++;
        }
        while(bb>aa-1)
        {
            ans[++cnt]=2;
            b>>=1;
            bb--;
        }
    }
    //cout<<cnt<<endl;
    bitset<33> aaa,ccc;
    aaa=a,ccc=c;
    for(int i=aa-1;i>=0;i--)
    {
        if(aaa[i]!=ccc[i]) ans[++cnt]=3;
        ans[++cnt]=2;
    }
    ans[++cnt]=4;
    cout<<cnt<<endl;
    for(int i=1;i<=cnt;i++)
    cout<<ans[i]<<" ";
    cout<<endl;
}
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie();
    cin>>T;
    while(T--) solve();
}