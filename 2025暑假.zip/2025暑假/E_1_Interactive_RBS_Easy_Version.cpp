#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T1,class T2=null_type,class T3=less<T1> > 
using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

int ask()
{
    int x;cin>>x;
    return x;
}
void solve()
{
    int n;cin>>n;
    int l=-1,r=-1;
    cout<<"?"<<' '<<n<<' ';
    for(int i=1;i<=n;i++)cout<<i<<' ';
    cout<<'\n';
    cout.flush();
    int x=ask();

    if(x==0){l=n,r=1;}
    else 
    {
        l=1,r=n;
        int mid=l+r>>1;

        auto chk=[&](int x)-> bool 
        {
            cout<<"?"<<' '<<mid-l+1<<' ';
            for(int i=l;i<=mid;i++)
            {
                cout<<i<<' ';
            }
            cout<<'\n';
            cout.flush();
            int c=ask();
            if(c>=1)return true;
            return false;
        };

        while(r-l>1)
        {
            mid=l+r>>1;
            if(chk(mid))
            {
                r=mid;
            }
            else l=mid;
        }
    }
    
    string s(n+1,'0');

    s[l]='(';
    s[r]=')';

    for(int i=1;i<n;i+=2)
    {
        cout<<"?"<<' '<<6<<' ';
        cout<<l<<' '<<r<<' '<<l<<' '<<i<<' '<<i+1<<' '<<r<<'\n';
        cout.flush();
        int x=ask();
        if(x==4){s[i]='(',s[i+1]=')';}
        else if(x==6){s[i]=')',s[i+1]='(';}
        else if(x==2){s[i]='(',s[i+1]='(';}
        else if(x==3){s[i]=')',s[i+1]=')';}
    }

    if((n&1)&&n!=l)
    {
        cout<<"?"<<' '<<2<<' '<<l<<' '<<n<<'\n';
        cout.flush();
        int x=ask();
        if(x==1){s[n]=')';}
        else s[n]='(';
    }

    cout<<"!"<<' ';
    for(int i=1;i<=n;i++)cout<<s[i];
    cout<<'\n';
    cout.flush();
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}
