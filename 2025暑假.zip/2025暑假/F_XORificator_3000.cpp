// #include<bits/stdc++.h>
// #include<bits/extc++.h>

// using namespace std;
// using namespace __gnu_pbds;

// #define int long long
// #define pb(x) push_back(x)
// #define ppb pop_back()
// #define fi first 
// #define se second 
// #define mkp make_pair
// #define SZ(x) ((int)((x).size()))
// #define lb(x) ((x) & (-(x)))
// #define bp(x) __builtin_popcountll(x)
// #define bc(x) __builtin_ctzll(x)
// #define rep(i,a,b) for(int i=a;i<=b;i++)
// #define rep_(i,a,b) for(int i=a;i>=b;i--)
// #define umap gp_hash_table
// typedef pair<int,int> pii;
// const int mod=1E9+7;
// const int inf=2E18;
// int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
// int gcd(int a,int b) { return b?gcd(b,a%b):a;}

// template <class T1,class T2> 
// struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

// template<class T1,class T2=null_type,class T3=less<T1> > 
// using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

// #ifdef ONLINE_JUDGE
// #define bug(...) void(0)
// #else 
// template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
// #endif
// template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

// int part(int x)
// {
//     if(x%4==0)return x;
//     if(x%4==1)return 1;
//     if(x%4==2)return x+1;
//     if(x%4==3)return 0;
// }

// void solve()
// {
//     int l,r,i,k;cin>>l>>r>>i>>k;
//     int Mod=1LL<<i;

//     int c1=part(r)^part(l-1);

//     int a=l>>i;
//     int b=r>>i;

//     if(l%Mod>k)a++;
//     if(r%Mod<k)b--;

//     int c2=part(b)^part(a-1);

//     int ans=c2<<i;
//     if((b-a+1)&1)ans+=k;

//     ans^=c1;

//     cout<<ans<<'\n';
// }
// signed main()
// {
//     ios::sync_with_stdio(false);cin.tie(nullptr);
//     int tt;cin>>tt;while(tt--)solve();
//     return 0;
// }


#include <iostream>
using namespace std;

long long xor_0_to_n(long long n) {
    if (n < 0) 
        return 0;
    long long mod = n & 3; // n % 4
    if (mod == 0) 
        return n;
    if (mod == 1) 
        return 1;
    if (mod == 2) 
        return n + 1;
    return 0; // mod==3
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        long long l, r, i_val, k;
        cin >> l >> r >> i_val >> k;
        long long M = (i_val == 0) ? 1 : (1LL << i_val);
        long long total_xor = xor_0_to_n(r) ^ xor_0_to_n(l - 1);

        long long r0 = l % M;
        long long x0;
        if (r0 <= k) {
            x0 = l + (k - r0);
        } else {
            x0 = l + (k - r0 + M);
        }

        long long S = 0;
        if (x0 <= r) {
            long long n_count = (r - x0) / M;
            long long cnt = n_count + 1;
            long long low_xor = (cnt & 1) ? k : 0;
            long long high_start = x0 >> i_val;
            long long high_end = high_start + n_count;
            long long high_xor = xor_0_to_n(high_end) ^ xor_0_to_n(high_start - 1);
            S = (high_xor << i_val) ^ low_xor;
        }

        long long ans = total_xor ^ S;
        cout << ans << '\n';
    }

    return 0;
}