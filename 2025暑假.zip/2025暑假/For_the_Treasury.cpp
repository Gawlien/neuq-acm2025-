// #include<bits/stdc++.h>
// #include<bits/extc++.h>

// using namespace std;
// using namespace __gnu_pbds;

// #define int long long
// #define pb(x) push_back(x)
// #define ppb pop_back()
// #define fi first 
// #define se second 
// #define mkp make_pair
// #define SZ(x) ((int)((x).size()))
// #define lb(x) ((x) & (-(x)))
// #define bp(x) __builtin_popcountll(x)
// #define bc(x) __builtin_ctzll(x)
// #define rep(i,a,b) for(int i=a;i<=b;i++)
// #define rep_(i,a,b) for(int i=a;i>=b;i--)
// #define umap gp_hash_table
// typedef pair<int,int> pii;
// const int mod=1E9+7;
// const int inf=2E18;
// int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
// int gcd(int a,int b) { return b?gcd(b,a%b):a;}

// template <class T1,class T2> 
// struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

// template<class T,class TT=null_type>
// using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

// #ifdef ONLINE_JUDGE
// #define bug(...) void(0)
// #else 
// template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
// #endif
// template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

// struct bao
// {
//     int val,cost,pos;
//     friend bool operator <(bao a,bao b)
//     {
//         return a.val+a.cost>b.val+b.cost;
//     }
// };
// void solve()
// {
//     int n,k,c;cin>>n>>k>>c;
//     std::priority_queue<bao>q;
//     for(int i=1;i<=k;i++)
//     {
//         int x;cin>>x;
//         q.push({x,(k-i+1)*c,i});
//     }
//     int C=0;
//     for(int i=k+1;i<=n;i++)
//     {
//         int x;cin>>x;
//         bao mn=q.top();
//         q.pop();
//         int val=mn.val;
//         int pos=mn.pos;
//         int cost=mn.cost;
//         if(x-val>c*(i-pos))
//         {
//             q.push({x,cost,pos});
//             C+=c*(i-pos);
//         }
//         else 
//         {
//             q.push(mn);
//         }
//     }

//     int ans=0;
//     while(!q.empty())
//     {
//         bao c=q.top();
//         q.pop();
//         ans+=c.val;
//     }
//     ans-=C;
//     cout<<ans<<'\n';
// }
// signed main()
// {
//     ios::sync_with_stdio(false);cin.tie(nullptr);
//     solve();
//     return 0;
// }


#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=3e5+10;
int T,n,k,cc,a[N],b[N],c[N],cnt1,cnt2,ans;
void init()
{
    cnt1=cnt2=ans=0;
}
void solve()
{
    cin>>n>>k>>cc;
    init();
    for(int i=1;i<=n;i++)
    {
       cin>>a[i];
       if(i<=k) ans+=a[i];
    }
    for(int i=1;i<=k;i++)
    b[++cnt1]=-a[i]-(k-i)*cc;
    for(int i=k+1;i<=n;i++)
    c[++cnt2]=a[i]-(i-k)*cc;
    sort(b+1,b+cnt1+1);
    reverse(b+1,b+cnt1+1);
    sort(c+1,c+cnt2+1);
    reverse(c+1,c+cnt2+1);
    for(int i=1;i<=cnt1&&i<=cnt2;i++)
    {
        if(b[i]+c[i]>0) ans=ans+b[i]+c[i];
    }
    cout<<ans<<endl;
}
signed main()
{
    ios::sync_with_stdio(0);cin.tie(0);
	cin.tie(0);cout.tie();
    T=1;//cin>>T;
    while(T--) solve();
}