// #include<bits/stdc++.h>
// #include<bits/extc++.h>

// using namespace std;
// using namespace __gnu_pbds;

// #define int long long
// #define pb(x) push_back(x)
// #define ppb pop_back()
// #define fi first 
// #define se second 
// #define mkp make_pair
// #define SZ(x) ((int)((x).size()))
// #define lb(x) ((x) & (-(x)))
// #define bp(x) __builtin_popcount(x)
// #define bc(x) __builtin_ctzll(x)
// #define rep(i,a,b) for(int i=a;i<=b;i++)
// #define rep_(i,a,b) for(int i=a;i>=b;i--)
// #define umap gp_hash_table
// typedef pair<int,int> pii;
// const int mod=1E9+7;
// const int inf=2E18;
// int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
// int gcd(int a,int b) { return b?gcd(b,a%b):a;}

// template <class T1,class T2> 
// struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

// template<class T,class TT=null_type>
// using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

// #ifdef ONLINE_JUDGE
// #define bug(...) void(0)
// #else 
// template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
// #endif
// template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

// struct node
// {
//     int to,val;
// };
// struct p
// {
//     int u,t,w;
//     bool operator>(const p& c)const 
//     {
//         if(t!=c.t)return t>c.t;
//         return w>c.w;
//     }
// };
// void solve()
// {
//     int n,m;cin>>n>>m;
//     vector<vector<node>> G(n+1);
//     vector<int>deg(n+1,0);

//     for(int i=1;i<=m;i++)
//     {
//         int u,v;cin>>u>>v;
//         G[v].push_back({u,deg[v]++});
//         G[u].push_back({v,deg[u]++});
//     }
//     // vector<vector<int>> dis(n + 1, vector<int>(2*n, inf));
//     vector<umap<int,int>>dis(n+1);

//     std::priority_queue<p, vector<p>, greater<p>>q;

//     dis[1][0]=0;
//     q.push({1,0,0});

//     int mt=inf,mw=inf;
//     while(!q.empty())
//     {
//         p c=q.top();
//         q.pop();
//         int u=c.u;
//         int t=c.t;
//         int w=c.w;
//         if(u==n)
//         {
//             if(t<mt)
//             {
//                 mt=t;
//                 mw=w;
//             }
//             else if(t==mt&&w<mw)
//             {
//                 mw=w;
//             }
//             break;
//         }
//         if(t>mt)continue;
//         int nt=t+1;
//         int nw=w+1;
//         if (nt<2*n&&nw<dis[u][nt])
//         {
//             dis[u][nt]=nw;
//             q.push({u,nt,nw});
//         }
//         int md=t%deg[u];
//         if (md<SZ(G[u]))
//         {
//             node e=G[u][md];
//             int v=e.to;
//             int mmt=t+1;
//             if (mmt<2*n&&w<dis[v][mmt])
//             {
//                 dis[v][mmt]=w;
//                 q.push({v,mmt,w});
//             }
//         }
//     }
//     cout<<mt<<' '<<mw<<'\n';
// }
// signed main()
// {
//     ios::sync_with_stdio(false);cin.tie(nullptr);
//     int tt;cin>>tt;while(tt--)solve();
//     return 0;
// }


// #include <iostream>
// #include <vector>
// #include <queue>
// #include <climits>
// using namespace std;

// struct Edge {
//     int to;
//     int idx;  // 边在顶点的边列表中的索引
// };

// struct State {
//     int u;    // 当前顶点
//     int t;    // 到达时间
//     int w;    // 等待时间

//     bool operator>(const State& other) const {
//         if (t != other.t) return t > other.t;
//         return w > other.w;
//     }
// };

// int main() {
//     ios::sync_with_stdio(false);
//     cin.tie(nullptr);

//     int t;
//     cin >> t;
//     while (t--) {
//         int n, m;
//         cin >> n >> m;
//         vector<vector<Edge>> adj(n + 1);  // 顶点从1开始
//         vector<int> deg(n + 1, 0);

//         for (int i = 0; i < m; ++i) {
//             int u, v;
//             cin >> u >> v;
//             adj[u].push_back({v, deg[u]++});
//             adj[v].push_back({u, deg[v]++});
//         }

//         // 初始化距离数组，dist[u][t] = 到达顶点u时间为t的最小等待时间
//         vector<vector<int>> dist(n + 1, vector<int>(2 * n, INT_MAX));
//         priority_queue<State, vector<State>, greater<State>> pq;

//         // 初始状态：顶点1，时间0，等待0
//         dist[1][0] = 0;
//         pq.push({1, 0, 0});

//         int min_time = INT_MAX;
//         int min_wait = INT_MAX;

//         while (!pq.empty()) {
//             State current = pq.top();
//             pq.pop();
//             int u = current.u;
//             int t = current.t;
//             int w = current.w;

//             // 如果已经到达顶点n，记录最优解
//             if (u == n) {
//                 if (t < min_time) {
//                     min_time = t;
//                     min_wait = w;
//                 } else if (t == min_time && w < min_wait) {
//                     min_wait = w;
//                 }
//                 // 由于使用优先队列，后续状态的时间不会更小，可以提前结束
//                 break;
//             }

//             // 如果当前状态的等待时间已经大于已知最优解，跳过
//             if (t > min_time) continue;

//             // 情况1：等待1秒
//             int new_t = t + 1;
//             int new_w = w + 1;
//             if (new_t < 2 * n && new_w < dist[u][new_t]) {
//                 dist[u][new_t] = new_w;
//                 pq.push({u, new_t, new_w});
//             }

//             // 情况2：移动
//             int mod = t % deg[u];
//             if (mod < adj[u].size()) {
//                 Edge e = adj[u][mod];
//                 int v = e.to;
//                 int move_t = t + 1;
//                 if (move_t < 2 * n && w < dist[v][move_t]) {
//                     dist[v][move_t] = w;
//                     pq.push({v, move_t, w});
//                 }
//             }
//         }

//         cout << min_time << " " << min_wait << "\n";
//     }

//     return 0;
// }


#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T,class TT=null_type>
using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

struct p
{
    int u,t,w; 
    bool operator>(const p& c)const
    {
        if (t!=c.t)return t>c.t; 
        return w>c.w; 
    }
};

void solve() {
    int n,m;cin>>n>>m;
    vector<vector<int>> G(n+1); 
    vector<int>deg(n+1,0);

    for(int i=1;i<=m;i++)
    {
        int u,v;cin>>u>>v;
        G[u].push_back(v);
        G[v].push_back(u);
        deg[u]++;
        deg[v]++;
    }

    vector<map<int,int>>dis(n+1);

    std::priority_queue<p,vector<p>,greater<p>>q;

    dis[1][0]=0;
    q.push({1,0,0});

    int mt=inf,mw=inf;

    while (!q.empty())
    {
        auto [u,t,w]=q.top();
        q.pop();
        if (u==n)
        {
            if(t<mt)
            {
                mt=t;
                mw=w;
            }else if(t==mt&&w<mw)
            {
                mw=w;
            }
            break;
        }
        if (t>mt)continue;

        if (dis[u].count(t)&&dis[u][t]<w)continue;

        int nt=t+1;
        int nw=w+1;
        if (!dis[u].count(nt)||nw<dis[u][nt])
        {
            dis[u][nt]=nw;
            q.push({u,nt,nw});
        }
        if (deg[u]==0) continue;
        int id=t%deg[u];
        int v=G[u][id];
        int mt=t+1; 
        if (!dis[v].count(mt)||w<dis[v][mt])
        {
            dis[v][mt]=w;
            q.push({v,mt,w});
        }
    }

    cout<<mt<<' '<<mw<<'\n';
}

signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}