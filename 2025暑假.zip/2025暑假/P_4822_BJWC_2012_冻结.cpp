#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T1,class T2=null_type,class T3=less<T1> > 
using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

struct node 
{
    int u,use,dis;
    friend bool operator <(node a,node b)
    {
        return a.dis>b.dis;
    }
};

struct p
{
    int to,val;
};

vector<vector<p> >G;
std::priority_queue<node>q;

void solve()
{
    int n,m,k;cin>>n>>m>>k;
    vector<vector<int> >dp(k+1,vector<int>(n+1,inf));
    vector<vector<int> >vis(k+1,vector<int>(n+1,0));

    G=vector<vector<p> >(n+1);

    for(int i=1;i<=m;i++)
    {
        int u,v,w;cin>>u>>v>>w;
        G[u].push_back({v,w});
        G[v].push_back({u,w});
    }

    auto Dij=[&]()->void 
    {
        dp[0][1]=0;
        q.push({1,0,0});
        while(!q.empty())
        {
            node t=q.top();
            q.pop();
            int u=t.u;
            int use=t.use;
            int dis=t.dis;
            if(vis[use][u])continue;
            vis[use][u]=1;
            for(auto x:G[u])
            {
                int v=x.to;
                int w=x.val;
                if(use<k&&dis+w/2<dp[use+1][v])
                {
                    dp[use+1][v]=dis+w/2;
                    q.push({v,use+1,dp[use+1][v]});
                }
                if(dis+w<dp[use][v])
                {
                    dp[use][v]=dis+w;
                    q.push({v,use,dp[use][v]});
                }
            }
        }
    };

    Dij();

    int ans=inf;

    for(int i=0;i<=k;i++)
    {
        ans=min(ans,dp[i][n]);
    }

    cout<<ans<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    solve();
    return 0;
}




// #include<bits/stdc++.h>
// #include<bits/extc++.h>

// using namespace std;
// using namespace __gnu_pbds;

// #define int long long
// #define pb(x) push_back(x)
// #define ppb pop_back()
// #define fi first 
// #define se second 
// #define mkp make_pair
// #define SZ(x) ((int)((x).size()))
// #define lb(x) ((x) & (-(x)))
// #define bp(x) __builtin_popcountll(x)
// #define bc(x) __builtin_ctzll(x)
// #define rep(i,a,b) for(int i=a;i<=b;i++)
// #define rep_(i,a,b) for(int i=a;i>=b;i--)
// #define umap gp_hash_table
// typedef pair<int,int> pii;
// const int mod=1E9+7;
// const int inf=2E18;
// int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
// int gcd(int a,int b) { return b?gcd(b,a%b):a;}

// template <class T1,class T2> 
// struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

// template<class T1,class T2=null_type,class T3=less<T1> > 
// using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

// #ifndef ONLINE_JUDGE
// #define bug(...) void(0)
// #else 
// template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
// #endif
// template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

// const int N=1E5+5;
// int p1[N],p2[N];
// int hs1[N][26],hs2[N][26];
// int b1=131,b2=13331;
// int M1=1E9+7,M2=1E9+9;

// void solve()
// {
//     int n,q;cin>>n>>q;
//     string s;cin>>s;
//     s=' '+s;
//     p1[0]=1,p2[0]=1;
//     for(int i=1;i<=n;i++)
//     {
//         for(int j=0;j<26;j++)
//         {
//             hs1[i][j]=(hs1[i-1][j]*b1%M1+(s[i]==j+'a'?j:0))%M1;
//             hs2[i][j]=(hs2[i-1][j]*b1%M2+(s[i]==j+'a'?j:0))%M2;
//         }
//         p1[i]=p1[i-1]*b1%M1;
//         p2[i]=p2[i-1]*b2%M2;
//     }

//     while(q--)
//     {
//         int l1,r1,l2,r2;cin>>l1>>r1>>l2>>r2;
//         int len=r1-l1+1;
//         string ans="";
//         for(int i=0;i<26;i++)
//         {
//             int c1=(hs1[r1][i]-(hs1[l1-1][i]*p1[len])%M1)%M1;
//             int d1=(hs2[r1][i]-(hs2[l1-1][i]*p2[len])%M2)%M2;
//             int c2=(hs1[r2][i]-(hs1[l2-1][i]*p1[len])%M1)%M1;
//             int d2=(hs2[r2][i]-(hs2[l2-1][i]*p2[len])%M2)%M2;
//             if(c1!=c2||d1!=d2)
//             {
//                 ans+=(i+'a');
//             }
//         }
//         cout<<SZ(ans)<<' '<<ans<<'\n';
//     }
// }
// signed main()
// {
//     ios::sync_with_stdio(false);cin.tie(nullptr);
//     solve();
//     return 0;
// }