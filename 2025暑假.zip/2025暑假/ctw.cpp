#include <bits/stdc++.h>
#include <bits/extc++.h>
using namespace std;
using namespace __gnu_pbds;
#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else
#include "debug.h"
#endif
#define int long long
#define pii pair<int,int>
#define pb emplace_back
template<class T1,class T2=null_type,class T3=less<T1>>
using ordered_set=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;
template<class...T>void out(const T&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}
const int N=2e5+3,inf=2e18,mod=998244353;
void solve()
{
    
}
signed main(){
    ios::sync_with_stdio(0);cin.tie(0);
    int t;cin>>t;
    while(t--)solve();
    return 0;
}