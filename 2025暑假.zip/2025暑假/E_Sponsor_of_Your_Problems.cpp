#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    string s1,s2;cin>>s1>>s2;
    int n=SZ(s1);
    s1=' '+s1;
    s2=' '+s2;
    int lim=1;
    int ans=0;
    int big=-1;
    for(int i=1;i<=n;i++)
    {
        int c1=s1[i]-'0';
        int c2=s2[i]-'0';
        if(!lim)continue;

        if(c1==c2&&lim)
        {
            if(big==-1)
            {
                ans+=2;
                //bug(i);
            }
            else lim=0;
        }
        else if(c1!=c2&&lim)
        {
            if(abs(c1-c2)>1&&big==-1)lim=0;

            if(big!=-1)
            {
                if(c1>c2&&big==1)lim=0;
                if(c1<c2&&big==2)lim=0;
                if(big==1&&(!(c1==0&&c2==9)))lim=0;
                if(big==2&&(!(c2==0&&c1==9))){lim=0;}
            }

            if(c1>c2&&big==-1)big=1;
            else if(c1<c2&&big==-1){big=2;bug(i);}

            if(lim){ans++;bug(i,big);}
        }
    }
    cout<<ans<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}