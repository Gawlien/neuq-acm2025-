#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T,class TT=null_type>
using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

int lcm(int a,int b)
{
    return a*b/(gcd(a,b));
}
void solve()
{
    int n;cin>>n;
    vector<int>p(n),s(n);
    for(int i=0;i<n;i++)cin>>p[i];
    for(int i=0;i<n;i++)cin>>s[i];

    int g=p[n-1];
    if(s[0]!=g){cout<<"NO"<<'\n';return;}

    int f=1;

    for(int i=1;i<n;i++)
    {
        if(p[i-1]%p[i]!=0)
        {
            f=0;break;
        }
    }
    if(!f){cout<<"NO"<<'\n';return;}

    for(int i=0;i<n-1;i++)
    {
        if(s[i+1]%s[i]!=0)
        {
            f=0;break;
        }
    }
    if(!f){cout<<"NO"<<'\n';return;}

    for(int i=0;i<n-1;i++)
    {
        if(gcd(p[i],s[i+1])!=g)
        {
            f=0;break;
        }
    }
    cout<<(f? "YES\n":"NO\n");
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}


