#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T1,class T2=null_type,class T3=less<T1> > 
using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int n;cin>>n;
    vector<int>a(n+1,0);
    cout<<"?"<<' '<<1<<' '<<n<<'\n';
    cout.flush();
    int x;cin>>x;
    a[n]=x;
    if(x==0)
    {
        cout<<"!"<<' '<<"IMPOSSIBLE"<<'\n';
        cout.flush();
        return;
    }

    if(x==1&&n==2)
    {
        cout<<"!"<<' '<<"01"<<'\n';
        cout.flush();
        return;
    }

    cout<<"?"<<' '<<1<<' '<<2<<'\n';
    cout.flush();
    int c;cin>>c;
    int f=0;
    string s(n+1,'0');
    if(c==1){s[1]='0',s[2]='1';f=1;}
    if(f)
    {
        a[2]=1;
        for(int i=3;i<n;i++)
        {
            cout<<"?"<<' '<<1<<' '<<i<<'\n';
            cout.flush();
            int x;cin>>x;
            if(x==a[i-1])s[i]='0',a[i]=x;
            else {s[i]='1',a[i]=x;}
        }

        if(a[n]!=a[n-1])s[n]='1';
        else s[n]='0';
        cout<<"!"<<' ';
        for(int i=1;i<=n;i++)cout<<s[i];
        cout<<'\n';
        cout.flush();
        return;
    }

    if(n==3)
    {
        if(x==1)
        {
            cout<<"!"<<' '<<"101"<<'\n';
            cout.flush();
        }
        else if(x==2)
        {
            cout<<"!"<<' '<<"001"<<'\n';
            cout.flush();
        }
        return;
    }
    bool ok=true;

    cout<<"?"<<' '<<3<<' '<<n<<'\n';
    cout.flush();
    int y;cin>>y;
    if(x==y){s[1]='1',s[2]='1';ok=false;}
    if(!ok)
    {
        string s(n+1,'2');
        int g=1;
        int cnt=0;
        for(int i=3;i<n;i++)
        {
            cout<<"?"<<' '<<1<<' '<<i<<'\n';
            cout.flush();
            int d;cin>>d;
            if(g)
            {
                a[i]=d;
                if(d>0)
                {
                    for(int j=i-1;j>=i-d;j--)
                    {
                        s[j]='0';
                    }
                    g=0;
                }
                else continue;
            }
            else 
            {
                a[i]=d;
                if(d==a[i-1])s[i]='0';
                else s[i]='1';
            }
        }
        if(g)
        {
            s[n]='1';
            for(int j=n-1;j>=n-x;j--)s[j]='0';
        }
        else 
        {
            if(x==a[n-1])s[n]='0';
            else s[n]='1';
        }
        cout<<"!"<<' ';
        for(int i=1;i<=n;i++)
        {
            if(s[i]=='2')cout<<"1";
            else cout<<s[i];
        }
        cout<<'\n';
        cout.flush();
        return;
    }

    a[1]=0,a[2]=0;
    int now=0;

    for(int i=3;i<n;i++)
    {
        cout<<"?"<<' '<<1<<' '<<i<<'\n';
        cout.flush();
        int x;cin>>x;
        if(ok)
        {
            if(x==0)
            {
                s[i]='0';
                now++;
                a[i]=0;
            }
            else 
            {
                if(x==now+1)
                {
                    s[1]='1';
                    s[2]='0';
                    s[i]='1';
                    a[i]=x;
                }
                else if(x==now+2)
                {
                    s[1]='0';
                    s[2]='0';
                    s[i]='1';
                    a[i]=x;
                }
                ok=false;
            }
        }
        else 
        {
            if(x==a[i-1])s[i]='0',a[i]=x;
            else {s[i]='1';a[i]=x;}
        }
    }

    if(ok)
    {
        s[n]='1';
        if(x==now+1){s[1]='1',s[2]='0';}
        else s[1]='0',s[2]='0';
    }
    else 
    {
        if(a[n]!=a[n-1])s[n]='1';
        else s[n]='0';
    }
    cout<<"!"<<' ';
    for(int i=1;i<=n;i++)cout<<s[i];
    cout<<'\n';
    cout.flush();
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}
