#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

vector<vector<int> >G;

void solve()
{
    int n;cin>>n;
    map<int,int>mp;
    G=vector<vector<int> >(n+1);
    for(int i=1;i<n;i++)
    {
        int u,v;cin>>u>>v;
        G[u].pb(v);
        G[v].pb(u);
        mp[u]++;
        mp[v]++;
    }
    int id=-1;
    for(int i=1;i<=n;i++)
    {
        if(mp[i]==2)
        {
            id=i;
            break;
        }
    }
    if(id==-1){cout<<"NO"<<'\n';return;}
    else cout<<"YES"<<'\n';
    int root=-1;
    int x=G[id][0];
    int y=G[id][1];
    for(int i=1;i<=n;i++)
    {
        if(i!=x&&i!=y&&i!=id&&mp[i]==1){root=i;break;}
    }
    if(root==-1)
    {
        cout<<x<<' '<<id<<'\n';
        cout<<id<<' '<<y<<'\n';
        return;
    }
    bug(x,y,id,root);
    vector<int>dep(n+1,0);
    vector<int>vis(n+1,0);
    dep[root]=1;
    vis[root]=1;
    auto dfs=[&](auto &self,int u,int fa,int now)->void
    {
        //if(SZ(G[u])==1){dep[u]=now;return;}
        for(auto v:G[u])
        {
            if(v==fa)continue;
            vis[v]=1;
            if((now&1)&&u!=id&&v!=id)cout<<u<<' '<<v<<'\n';
            else if(now%2==0&&u!=id&&v!=id)cout<<v<<' '<<u<<'\n';
            dep[v]=now+1;
            if((vis[x]==1&&v==y)||(vis[y]==1&&v==x))self(self,v,u,now+2);
            else self(self,v,u,now+1);
        }
    };
    dfs(dfs,root,0,1);
    if(dep[x]>dep[y])swap(x,y);
    if(dep[x]&1)
    {
        cout<<x<<' '<<id<<'\n';
        cout<<id<<' '<<y<<'\n';
    }
    else 
    {
        cout<<id<<' '<<x<<'\n';
        cout<<y<<' '<<id<<'\n';
    }
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}