#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T1,class T2=null_type,class T3=less<T1> > 
using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

bool cmp(pii &a,pii &b)
{
    if(a.fi!=b.fi)return a.fi<b.fi;
    return a.se<b.se;
}
void solve()
{
    int n,m;cin>>n>>m;
    string s(2*n+1,'0');
    for(int i=1;i<=n;i++)s[i]='(';
    for(int i=n+1;i<=2*n;i++)s[i]=')';

    vector<pii>seg(m+1);

    for(int i=1;i<=m;i++)
    {
        cin>>seg[i].fi>>seg[i].se;
    }

    sort(seg.begin()+1,seg.end(),cmp);
    int now=2*n+1;
    int id=n;

    for(int i=m;i>=1;i--)
    {
        int x=seg[i].fi;
        int y=seg[i].se;
        if(y>=now)continue;
        if(x<=id)continue;
        else 
        {
            s[x]='(';
            now=x;
            while(s[id]==')')
            {
                id--;
            }
            if(id<=1){cout<<-1<<'\n';return;}
            s[id]=')';
            while(s[id]==')')
            {
                id--;
            }
        }
    }

    stack<char>st;
    for(int i=1;i<=2*n;i++)
    {
        if(st.empty()){st.push(s[i]);continue;}
        if(s[i]=='(')st.push(s[i]);
        else st.pop();
    }
    if(!st.empty()){cout<<-1<<'\n';return;}

    for(int i=1;i<=2*n;i++)cout<<s[i];
    cout<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}
