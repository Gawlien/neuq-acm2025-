#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}


void solve()
{
    int n;cin>>n;
    vector<int>cnt(n+1,0);
    for(int i=1;i<=n;i++)
    {
        int x;cin>>x;
        cnt[x]++;
    }

    vector<int>c(n+2,0);

    for(int i=0;i<=n;i++)
    {
        int lo=cnt[i];
        int hi=n-i;
        if(lo<=hi)
        {
            c[lo]++;
            c[hi+1]--;
        }
        if(cnt[i]==0)break;
    }

    int ans=0;
    for(int i=0;i<=n;i++)
    {
        ans+=c[i];
        cout<<ans<<" \n"[i==n];
    }
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}