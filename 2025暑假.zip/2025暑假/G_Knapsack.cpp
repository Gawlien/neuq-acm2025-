#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T1,class T2=null_type,class T3=less<T1> > 
using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

struct b
{
    int cost,val;
    friend bool operator < (b x,b y)
    {
        return x.val>y.val;
    }
};
bool cmp(b &x,b &y)
{
    if(x.cost!=y.cost)return x.cost>y.cost;
    return x.val>y.val;
}
void solve()
{
    int n,w,k;cin>>n>>w>>k;
    vector<b>a(n+1);
    for(int i=1;i<=n;i++)
    {
        cin>>a[i].cost>>a[i].val;
    }

    sort(a.begin()+1,a.end(),cmp);

    std::priority_queue<b>q;

    int now=0;
    vector<int>pre(n+1,0);

    for(int i=1;i<=n;i++)
    {
        if(k==0){pre[i]=0;continue;}
        if(SZ(q)==k)
        {
            b c=q.top();
            q.pop();
            int cc=a[i].val;
            if(cc>c.val)
            {
                now+=(cc-c.val);
                q.push(a[i]);
            }
            else q.push(c);
            pre[i]=now;
        }
        else 
        {
            now+=a[i].val;
            q.push(a[i]);
            pre[i]=now;
        }
    }

    //for(int i=1;i<=n;i++)bug(i,pre[i]);
    // vector<int>dp(w+1,-inf);
    vector<vector<int> >dp(n+2,vector<int>(w+1,0));
    vector<int>mx(n+2,0);
    for(int i=1;i<=n+1;i++)
    {
        dp[i][0]=0;
    }
    for(int i=0;i<=w;i++)
    {
        dp[0][i]=0;
    }
    for(int i=n;i>=1;i--)
    {
        for(int j=0;j<=w;j++)
        {
            dp[i][j]=max(dp[i+1][j],j>=a[i].cost?dp[i+1][j-a[i].cost]+a[i].val:0);
            mx[i]=max(mx[i],dp[i][j]);
            //bug(i,j,dp[i][j]);
        }
        // bug(i,mx[i]);
        // bug(dp[i][5]);
    }

    int ans=0;

    for(int i=0;i<=n;i++)
    {
        ans=max(ans,pre[i]+mx[i+1]);
    }

    cout<<ans<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    solve();
    return 0;
}
