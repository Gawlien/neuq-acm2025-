#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int n;cin>>n;
    int sum=0;
    vector<int>v(n+1);
    //int b=0;
    rep(i,1,n)
    {
        cin>>v[i];
        sum+=v[i];
    }

    if(sum&1){cout<<-1<<'\n';return;}

    int f=0;
    rep(i,1,n)
    {
        if(v[i]>sum/2){f=1;break;}
    }
    if(f){cout<<-1<<'\n';return;}

    int cnt=0;
    bool ok=false;
    for(int i=1;i<=n;i++)
    {
        cnt+=v[i];
        if(cnt==sum-cnt){ok=true;break;}
    }
    if(ok)
    {
        cout<<1<<'\n';
        for(int i=1;i<=n;i++)cout<<v[i]<<" \n"[i==n];
        return;
    }

    int pos=-1;
    int ret=0;
    for(int i=1;i<=n;i++)
    {
        ret+=v[i];
        if(ret>=sum/2){pos=i;break;}
    }

    int x=0,y=0,z=0;
    for(int i=1;i<=n;i++)
    {
        if(i<pos)x+=v[i];
        else if(i==pos)y+=v[i];
        else z+=v[i];
    }

    int w=(x+y-z)/2;
    //if(x<z)w++;
    int more=(x+z-y)/2;
    bug(pos,w,more);
    cout<<2<<'\n';
    for(int i=1;i<pos;i++){cout<<v[i]<<' ';v[i]=0;}
    cout<<w<<' ';
    int rec=more;
    for(int i=pos+1;i<=n;i++)
    {
        if(rec>=v[i]){cout<<v[i]<<' ';rec-=v[i];v[i]=0;}
        else {cout<<rec<<' ';v[i]=v[i]-rec;rec=0;}
    }
    cout<<'\n';
    for(int i=1;i<=n;i++)
    {
        if(i!=pos)cout<<v[i]<<' ';
        else cout<<y-w<<' ';
    }
    cout<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}