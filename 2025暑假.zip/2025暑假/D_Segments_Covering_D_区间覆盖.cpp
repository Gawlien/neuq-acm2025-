#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=998244353;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T1,class T2=null_type,class T3=less<T1> > 
using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

using i64=long long;
template<class T>
constexpr T power(T a, i64 b) {T res = 1;for (; b != 0; b /= 2, a *= a) {if (b & 1) {res *= a;}}return res;}
 
template<int M>
struct ModInt {
public:
    constexpr ModInt() : x(0) {}
 
    template<std::signed_integral T>
    constexpr ModInt(T x_) {T v = x_ % M;if (v < 0) {v += M;}x = v;}
 
    constexpr int val() const {return x;}
 
    constexpr ModInt operator-() const {ModInt res;res.x = (x == 0 ? 0 : M - x);return res;}
 
    constexpr ModInt inv() const {return power(*this, M - 2);}
 
    constexpr ModInt &operator*=(const ModInt &rhs) &{x = i64(x) * rhs.val() % M;return *this;}
 
    constexpr ModInt &operator+=(const ModInt &rhs) &{x += rhs.val();if (x >= M) { x -= M;}return *this;}
 
    constexpr ModInt &operator-=(const ModInt &rhs) &{x -= rhs.val();if (x < 0) {x += M;}return *this;}
 
    constexpr ModInt &operator/=(const ModInt &rhs) &{return *this *= rhs.inv();}
 
    friend constexpr ModInt operator*(ModInt lhs, const ModInt &rhs) {lhs *= rhs;return lhs;}
 
    friend constexpr ModInt operator+(ModInt lhs, const ModInt &rhs) {lhs += rhs;return lhs;}
 
    friend constexpr ModInt operator-(ModInt lhs, const ModInt &rhs) {lhs -= rhs;return lhs;}
 
    friend constexpr ModInt operator/(ModInt lhs, const ModInt &rhs) {lhs /= rhs;return lhs;}
 
    friend constexpr std::istream &operator>>(std::istream &is, ModInt &a) {i64 i;is >> i;a = i;return is;}
 
    friend constexpr std::ostream &operator<<(std::ostream &os, const ModInt &a) {return os << a.val();}
 
    friend constexpr std::strong_ordering operator<=>(ModInt lhs, ModInt rhs) {return lhs.val() <=> rhs.val();}
 
private:
    int x;
};
 
// M: Modulo value, should be prime.
// SIZE: size of precalculated values for factorial (n!) and its modular inverse.
template<int M, typename T = ModInt<M>>
struct Comb {
    std::vector<T> fac;
    std::vector<T> facInv;
    constexpr static int MAX = 4194304;
 
    Comb() {fac.assign(1, 1);facInv.assign(1, 1);}
 
    template<std::signed_integral U>
    T P(U n, U m) 
    {
        assert(n >= 0 && m >= 0 && m <= n);
        if (n >= MAX) 
        {
            T res = 1;
            while (m--) res *= n--;
            return res;
        }
        enlarge(n);
        return fac[n] * facInv[n - m];
    }
 
    template<std::signed_integral U>
    T C(U n, U m) 
    {
        auto res = P(n, m);
        enlarge(m);
        return facInv[m] * res;
    }
 
    bool enlarge(int n) 
    {
        if (n >= MAX) return false;
        if (n >= fac.size()) 
        {
            int sz = fac.size();
            int nsz = std::bit_ceil(unsigned(n + 1));
            fac.resize(nsz);
            facInv.resize(nsz);
            for (int i = sz; i < nsz; i++) 
            {
                fac[i] = fac[i - 1] * i;
                facInv[i] = fac[i].inv();
            }
        }
        return true;
    }
 
    // Lucas's theorem: C(a,b) % M.
    template<std::signed_integral U>
    T lucas(U a, U b) 
    {
        T res = 1;
        while (a && b) 
        {
            U ma = a % M, mb = b % M;
            if (ma < mb) return 0;
            res *= C(ma, mb);
            a /= M, b /= M;
        }
        return res;
    }
 
    T catalan(int n) {return C(2 * n, n) / (n + 1);}
};
 
constexpr int M = 998244353;
using Z = ModInt<M>;
Comb<M> comb;
 
template<std::signed_integral U>
Z P(U n, U m) {return comb.P(n, m);}
 
template<std::signed_integral U>
Z C(U n, U m) {return comb.C(n, m);}


void solve()
{
    int n,m;cin>>n>>m;
    vector<array<int,4> >a(n);
    for(int i=0;i<n;i++)
    {
        cin>>a[i][0]>>a[i][1]>>a[i][2]>>a[i][3];
    }

    vector<Z>c(m+1,1);

    for(auto [l,r,p,q]:a)
    {
        c[r]*=(q-p);
        c[r]/=q;
    }

    vector<Z>qz(m+1,1);

    for(int i=1;i<=m;i++)
    {
        qz[i]=qz[i-1]*c[i];
    }

    ranges::sort(a);

    vector<Z>dp(m+1,0);
    dp[0]=1;

    for(auto [l,r,p,q]:a)
    {
        if(dp[l-1].val()==0)continue;
        dp[r]+=dp[l-1]*p/(q-p)*qz[r]/qz[l-1];
    }

    cout<<dp[m]<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    solve();
    return 0;
}
