#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=1e9+7;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

vector<vector<int> >G1,G2,G;

struct node
{
    pii u;int val;
    friend bool operator <(const node &a,const node &b){return a.val>b.val;}
};

priority_queue<node>q;

const int inf=1E18;

void solve()
{
    int n,s1,s2;cin>>n>>s1>>s2;
    G1=vector<vector<int> >(n+1);
    G2=vector<vector<int> >(n+1);
    set<pii>s;
    map<int,int>mp;

    int m1;cin>>m1;
    for(int i=1;i<=m1;i++)
    {
        int u,v;cin>>u>>v;
        G1[u].pb(v);
        G1[v].pb(u);
        if(u>v)swap(u,v);
        s.insert({u,v});
    }
    int m2;cin>>m2;
    for(int i=1;i<=m2;i++)
    {
        int u,v;cin>>u>>v;
        G2[u].pb(v);
        G2[v].pb(u);
        if(u>v)swap(u,v);
        if(s.find({u,v})!=s.end())
        {
            mp[u]=1;
            mp[v]=1;
        }
    }

    vector<vector<int> >dis(n+1,vector<int>(n+1,inf));
    map<pii,int>vis;
    dis[s1][s2]=0;
    q.push({{s1,s2},dis[s1][s2]});
    bug("1",s1,s2);
    while(!q.empty())
    {
        pii rec=q.top().u;
        q.pop();
        if(vis[rec])continue;
        vis[rec]=1;
        int a=rec.fi;
        int b=rec.se;
        bug(a,b);
        for(auto c:G1[a])
        {
            for(auto d:G2[b])
            {
                int w=abs(c-d);
                if(dis[c][d]>dis[a][b]+w)
                {
                    dis[c][d]=dis[a][b]+w;
                    bug(c,d,dis[c][d]);
                    q.push({{c,d},dis[c][d]});
                }
            }
        }
    }
    int ans=inf;
    for(int i=1;i<=n;i++)
    {
        if(mp[i]){ans=min(ans,dis[i][i]);}
    }
    if(ans==inf)ans=-1;
    cout<<ans<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}