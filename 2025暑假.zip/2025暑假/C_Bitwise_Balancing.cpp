#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T1,class T2=null_type,class T3=less<T1> > 
using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int b,c,d;cin>>b>>c>>d;
    if(d<b-c){cout<<-1<<'\n';return;}
    int ans=0;

    for(int i=1;i<=60;i++)
    {
        if((d>>(i-1)&1)==1)
        {
            if(((b>>(i-1)&1)==0)&&((c>>(i-1)&1)==1)){cout<<-1<<'\n';return;}
            //bug(i,b>>(i-1)&1,c>>(i-1)&1,d>>(i-1)&1);
            if(((b>>(i-1)&1)==0)&&((c>>(i-1)&1)==0)){ans+=(1LL<<(i-1));}
            //bug(i,ans);
        }
        else 
        {
            if(((b>>(i-1)&1)==0)&&((c>>(i-1)&1)==0))continue;
            if(((b>>(i-1)&1)==1)&&((c>>(i-1)&1)==0)){cout<<-1<<'\n';return;}
            else ans+=(1LL<<(i-1));
        }
    }

    if((ans|b)-(ans&c)==d)cout<<ans<<'\n';
    else cout<<ans<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}

