#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T1,class T2=null_type,class T3=less<T1> > 
using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

int a[20];
int len;
int dp[20][11][2][2];

int dfs(int pos,int pre,int lead,int lim)
{
    if(pos>len)return 1;
    if(dp[pos][pre][lead][lim]!=-1&&(!lead)&&(!lim))return dp[pos][pre][lead][lim];
    int ret=0;
    int mx=lim? a[len-pos+1]:9;
    for(int i=0;i<=mx;i++)
    {
        if(!lead&&abs(i-pre)<2)continue;
        if(i==0&&lead)ret+=dfs(pos+1,0,1,lim&&(i==mx));
        else ret+=dfs(pos+1,i,0,lim&&(i==mx));
    }
    if(!lim&&!lead)dp[pos][pre][lead][lim]=ret;
    return ret;
}
int part(int x)
{
    len=0;
    memset(a,0,sizeof(a));
    while(x)
    {
        a[++len]=x%10;
        x/=10;
    }
    memset(dp,-1,sizeof(dp));
    return dfs(1,0,1,1);
}
void solve()
{
    int l,r;cin>>l>>r;

    cout<<part(r)-part(l-1)<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    solve();
    return 0;
}


// #include<bits/stdc++.h>
// #include<bits/extc++.h>

// using namespace std;
// using namespace __gnu_pbds;

// #define int long long
// #define pb(x) push_back(x)
// #define ppb pop_back()
// #define fi first 
// #define se second 
// #define mkp make_pair
// #define SZ(x) ((int)((x).size()))
// #define lb(x) ((x) & (-(x)))
// #define bp(x) __builtin_popcountll(x)
// #define bc(x) __builtin_ctzll(x)
// #define rep(i,a,b) for(int i=a;i<=b;i++)
// #define rep_(i,a,b) for(int i=a;i>=b;i--)
// #define umap gp_hash_table
// typedef pair<int,int> pii;
// const int mod=1E9+7;
// const int inf=2E18;
// int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
// int gcd(int a,int b) { return b?gcd(b,a%b):a;}

// template <class T1,class T2> 
// struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

// template<class T1,class T2=null_type,class T3=less<T1> > 
// using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

// #ifdef ONLINE_JUDGE
// #define bug(...) void(0)
// #else 
// template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
// #endif
// template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

// int a[20];
// int len;
// int dp[20][11][2][2];

// int dfs(int pos,int pre,int lead,int lim)
// {
//     if(pos>len)return 1;
//     if(dp[pos][pre][lead][lim]!=-1&&(!lead)&&(!lim))return dp[pos][pre][lead][lim];
//     int ret=0;
//     int mx=lim? a[len-pos+1]:9;
//     for(int i=0;i<=mx;i++)
//     {
//         // 修正1：只在非前导零状态检查数字差值
//         if(!lead && abs(i-pre)<2) continue;
        
//         if(i==0 && lead) {
//             // 修正2：正确传递lim状态
//             ret += dfs(pos+1, 0, 1, lim && (i==mx));
//         } else {
//             ret += dfs(pos+1, i, lead?0:0, lim && (i==mx));
//         }
//     }
//     if(!lim&&!lead)dp[pos][pre][lead][lim]=ret;
//     return ret;
// }
// int part(int x)
// {
//     len=0;
//     memset(a,0,sizeof(a));
//     // 处理x=0的情况
//     if(x==0){
//         a[++len]=0;
//     } else {
//         while(x)
//         {
//             a[++len]=x%10;
//             x/=10;
//         }
//     }
//     memset(dp,-1,sizeof(dp));
//     return dfs(1,0,1,1);
// }
// void solve()
// {
//     int l,r;cin>>l>>r;
//     // 处理l=0的情况
//     int left = (l==0) ? 0 : part(l-1);
//     int right = part(r);
//     cout<<right - left<<'\n';
// }
// signed main()
// {
//     ios::sync_with_stdio(false);cin.tie(nullptr);
//     solve();
//     return 0;
// }