// #include<bits/stdc++.h>
// #include<bits/extc++.h>

// using namespace std;
// using namespace __gnu_pbds;

// #define int long long
// #define pb(x) push_back(x)
// #define ppb pop_back()
// #define fi first 
// #define se second 
// #define mkp make_pair
// #define SZ(x) ((int)((x).size()))
// #define lb(x) ((x) & (-(x)))
// #define bp(x) __builtin_popcount(x)
// #define bc(x) __builtin_ctzll(x)
// #define rep(i,a,b) for(int i=a;i<=b;i++)
// #define rep_(i,a,b) for(int i=a;i>=b;i--)
// #define umap gp_hash_table
// typedef pair<int,int> pii;
// const int mod=1E9+7;
// const int inf=2E18;
// int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
// int gcd(int a,int b) { return b?gcd(b,a%b):a;}

// template <class T1,class T2> 
// struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

// template<class T,class TT=null_type>
// using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

// #ifdef ONLINE_JUDGE
// #define bug(...) void(0)
// #else 
// template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
// #endif
// template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

// void solve()
// {
    
// }
// signed main()
// {
//     ios::sync_with_stdio(false);cin.tie(nullptr);
//     int tt;cin>>tt;while(tt--)solve();
//     return 0;
// }

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

typedef long long ll;
typedef pair<ll, int> pli; // (cost, node index)

const int NUM_NODES = 17;

vector<vector<int>> build_graph() {
    vector<vector<int>> graph(NUM_NODES);
    graph[0] = {1, 4};
    graph[1] = {0, 2, 5};
    graph[2] = {1, 3, 6};
    graph[3] = {2, 6};
    graph[4] = {0, 5, 7};
    graph[5] = {1, 4, 6, 8};
    graph[6] = {2, 3, 5, 9};
    graph[7] = {4, 8, 11};
    graph[8] = {5, 7, 9, 12};
    graph[9] = {6, 8, 10, 13};
    graph[10] = {9, 13};
    graph[11] = {7, 12, 14};
    graph[12] = {8, 11, 13, 15};
    graph[13] = {9, 10, 12, 16};
    graph[14] = {11, 15};
    graph[15] = {12, 14, 16};
    graph[16] = {13, 15};
    return graph;
}

int main() {
    vector<vector<int>> graph = build_graph();
    int T;
    cin >> T;

    while (T--) {
        vector<ll> value(NUM_NODES);
        for (int i = 0; i < NUM_NODES; i++) {
            cin >> value[i];
        }

        vector<ll> cost(NUM_NODES);
        for (int i = 0; i < NUM_NODES; i++) {
            cost[i] = value[i] / 6 + 1;
        }
        const int START = 14;
        cost[START] = 0;

        ll n;
        cin >> n;

        vector<bool> visited(NUM_NODES, false);
        priority_queue<pli, vector<pli>, greater<pli>> pq;

        int count = 1;
        ll total_cost = 0;
        visited[START] = true;

        for (int neighbor : graph[START]) {
            if (!visited[neighbor]) {
                pq.push({cost[neighbor], neighbor});
            }
        }

        while (!pq.empty()) {
            auto [c, u] = pq.top();
            pq.pop();
            if (visited[u]) continue;
            if (total_cost + c > n) break;
            total_cost += c;
            count++;
            visited[u] = true;
            for (int v : graph[u]) {
                if (!visited[v]) {
                    pq.push({cost[v], v});
                }
            }
        }
        cout << count << '\n';
    }
    return 0;
}