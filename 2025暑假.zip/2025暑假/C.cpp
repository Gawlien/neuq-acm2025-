// #include<bits/stdc++.h>

// using namespace std;

// #define int long long
// #define pb(x) push_back(x)
// #define ppb pop_back()
// #define fi first 
// #define se second 
// #define mkp make_pair
// #define SZ(x) ((int)((x).size()))
// #define lb(x) ((x) & (-(x)))
// #define bp(x) __builtin_popcount(x)
// #define bc(x) __builtin_ctzll(x)
// #define rep(i,a,b) for(int i=a;i<=b;i++)
// #define rep_(i,a,b) for(int i=a;i>=b;i--)
// typedef pair<int,int> pii;
// const int mod=1e9+7;
// int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
// int gcd(int a,int b) { return b?gcd(b,a%b):a;}

// #ifdef ONLINE_JUDGE
// #define bug(...)
// #else 
// template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
// #endif
// template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

// void solve()
// {
//     int l,r;cin>>l>>r;
//     if(l==r)
//     {
//         if(l==1)cout<<0<<'\n';
//         else cout<<"infty"<<'\n';
//         return;
//     }

//     int x=(r-2)/(r-l);
//     bug(x);
//     if(x==0){cout<<0<<'\n';return;}
//     int all=l*x-1;
//     int a=r-l;
//     cout<<all-x*(x-1)*a/2-(x-1)<<'\n';
// }
// signed main()
// {
//     ios::sync_with_stdio(false);cin.tie(nullptr);
//     int tt;cin>>tt;while(tt--)solve();
//     return 0;
// }

#include<bits/stdc++.h>

using namespace std;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
typedef pair<int,int> pii;
const int mod=998244353;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

const int N=1E5+10;
int j[N];

void init()
{
    j[0]=1;
    for(int i=1;i<N;i++)
    {
        j[i]=(j[i-1]*i)%mod;
    }
}
int f(int x)
{
    int k=j[x];
    x/=2;
    if(x==1)return 1;
    int c=fpw(2,x);
    int inv=fpw((c*j[x])%mod,mod-2);
    bug(x,k,inv,c);
    return (bug((k*inv)%mod),(k*inv)%mod);
}
void solve()
{
    int n;cin>>n;
    map<int,int>ind;

    rep(i,1,n-1)
    {
        int u,v;cin>>u>>v;
        ind[v]++;
        ind[u]++;
    }
    int ans=1;
    rep(i,1,n)
    {
        if(ind[i]>2)
        {
            if(ind[i]&1)
            {
                ans=(ans*(ind[i]))%mod;
                ans=(ans*(f(ind[i]-1)))%mod;
            }
            else ans=(ans*(f(ind[i])))%mod;
        }
    }
    cout<<ans%mod<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    init();
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}