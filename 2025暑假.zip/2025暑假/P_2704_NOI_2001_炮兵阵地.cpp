#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T,class TT=null_type>
using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

int dp[105][1<<10][1<<10];
int zy[1<<10];
int a[105];
int num[1<<10];

void solve()
{
    int n,m;cin>>n>>m;
    int cnt=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            char c;cin>>c;
            if(c=='H')a[i]+=(1<<(j-1));
        }
    }

    int mx=(1<<m)-1;
    for(int i=0;i<=mx;i++)
    {
        if(!(i&(i<<1))&&!(i&i<<2))
        {
            cnt++;
            zy[cnt]=i;
            int now=i;
            while(now>0)
            {
                if(now&1)num[cnt]++;
                now>>=1;
            }
        }
    }

    for(int i=1;i<=cnt;i++)
    {
        for(int j=1;j<=cnt;j++)
        {
            if(!(zy[i]&zy[j])&&!(zy[i]&a[2])&&!(zy[j]&a[1]))
            {
                dp[2][i][j]=num[j]+num[i];
            }
        }
    }

    int ans=0;

    for(int i=3;i<=n;i++)
    {
        for(int j=1;j<=cnt;j++)
        {
            if(!(zy[j]&a[i]))
            {
                for(int k=1;k<=cnt;k++)
                {
                    if(!(zy[k]&a[i-1])&&!(zy[k]&zy[j]))
                    {
                        for(int p=1;p<=cnt;p++)
                        {
                            if(!(zy[p]&a[i-2])&&!(zy[p]&zy[k])&&!(zy[p]&zy[j]))
                            {
                                dp[i][j][k]=max(dp[i][j][k],dp[i-1][k][p]+num[j]);
                                ans=max(ans,dp[i][j][k]);
                            }
                        }
                    }
                }
            }
        }
    }
    cout<<ans<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    solve();
    return 0;
}
