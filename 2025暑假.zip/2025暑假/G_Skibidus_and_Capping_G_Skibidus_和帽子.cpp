#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T,class TT=null_type>
using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

const int mx=2E5+10;

//const int N=1e7+10;
bool is[mx];     //存放合数
int su[mx];     //存放质数
int cnt;

int can[mx];
umap<int,pii>ump;
void init(int x)
{
    for(int i=2;i<=x;i++)
    {
        if(!is[i])
        {
            su[cnt++]=i;
        }
        for(int j=0;i*su[j]<=x;j++)
        {
            is[i*su[j]]=true;
            if(!is[i])
            {
                can[i*su[j]]=1;
                ump[i*su[j]]=mkp(i,su[j]);
            }
            if(i%su[j]==0)break;
        }
    }
}
void solve()
{
    int n;cin>>n;
    vector<int>a(n+1);
    vector<int>pri;
    int ans=0;
    vector<int>mp(n+1,0);
    vector<int>have(n+1,0);
    vector<int>s;
    rep(i,1,n)
    {
        cin>>a[i];
        if(!have[a[i]])
        {
            s.pb(a[i]);
            have[a[i]]=1;
        }
        mp[a[i]]++;
    }
    for(int i:s)
    {
        if(!is[i]){pri.pb(i);}
        if(can[i])
        {
            ans+=mp[i];
            ans+=(mp[i]-1)*mp[i]/2;
            int x=ump[i].fi;
            int y=ump[i].se;
            if(x==y)
            ans+=mp[x]*mp[i];
            else ans+=(mp[y]+mp[x])*mp[i];
        }
    }
    
    int x=0,y=0;
    for(int i=0;i<SZ(pri);i++)
    {
        x+=mp[pri[i]];
        y+=mp[pri[i]]*mp[pri[i]];
    }
    ans+=(x*x-y)/2;
    cout<<ans<<'\n';
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    init(mx);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}

