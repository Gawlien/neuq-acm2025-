#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcountll(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T1,class T2=null_type,class T3=less<T1> > 
using rbt=tree<T1,T2,T3,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

void solve()
{
    int q;cin>>q;
    vector<int>fa(30005,0);
    vector<int>num(30005,1);
    vector<int>front(30005,0);

    for(int i=1;i<=30000;i++)fa[i]=i;

    auto find=[&](auto &self,int x)->int 
    {
        if(x==fa[x])return x;
        int now=self(self,fa[x]);
        front[x]+=front[fa[x]];
        fa[x]=now;
        return fa[x];
    };

    // auto join=[&](int x,int y)->void 
    // {
    //     int u=find(find,x);
    //     int v=find(find,y);
    //     if(u!=v);
    //     fa[u]=v;
    // };

    while(q--)
    {
        char c;
        int x,y;
        cin>>c>>x>>y;
        int fx=find(find,x);
        int fy=find(find,y);
        if(c=='M')
        {
            front[fx]+=num[fy];
            fa[fx]=fy;
            num[fy]+=num[fx];
            num[fx]=0;
        }
        else if(c=='C')
        {
            if(fx!=fy){cout<<-1<<'\n';continue;}
            else 
            {   
                cout<<abs(front[x]-front[y])-1<<'\n';
            }
        }
    }
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    solve();
    return 0;
}


// #include<bits/stdc++.h>
// using namespace std;
// int fa[30001],front[30001],num[30001],x,y,i,j,n,T,ans;    //fa[i]表示飞船i的祖先
// //front[i]表示飞船i与其所在列队头的距离
//                                         //num[i]表示第i列的飞船数量 
// char ins;
// int find(int n){                                        //查找祖先的函数 
//     if(fa[n]==n)return fa[n];
//     int fn=find(fa[n]);                                    //先递归找到祖先 
//     front[n]+=front[fa[n]];    //在回溯的时候更新front（因为更新时要用到正确的front[祖先]，
//                                     //所以只能在回溯的时候更新） 
//     return fa[n]=fn;
// }
// int main(){
//     cin>>T;
//     for(i=1;i<=30000;++i){                                //定初值 
//         fa[i]=i;
//         front[i]=0;
//         num[i]=1;
//     }
//     while(T--){
//         cin>>ins>>x>>y;
//         int fx=find(x);                                    //fx为x所在列的队头 
//         int fy=find(y);                                    //fy同上 
//         if(ins=='M'){
//             front[fx]+=num[fy];        //更新front[x所在列队头(现在在y所在队列后面)]
// //即加上y所在队列的长度 
//             fa[fx]=fy;                                    //将fy设为fx的祖先 
//             num[fy]+=num[fx];                            //更新以fy为队头队列的长度 
//             num[fx]=0;                        //以fx为队头的队列已不存在，更新 
//         }
//         if(ins=='C'){
//             if(fx!=fy)cout<<"-1"<<endl;            //若x和y的祖先不相同，则不在同一列 
// else cout<<abs(front[x]-front[y])-1<<endl;    //否则利用x和y离队头的距离算
// //出它们的距离 
//         }
//     }
//     return 0;
// }