#include<bits/stdc++.h>
#include<bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;

#define int long long
#define pb(x) push_back(x)
#define ppb pop_back()
#define fi first 
#define se second 
#define mkp make_pair
#define SZ(x) ((int)((x).size()))
#define lb(x) ((x) & (-(x)))
#define bp(x) __builtin_popcount(x)
#define bc(x) __builtin_ctzll(x)
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define rep_(i,a,b) for(int i=a;i>=b;i--)
#define umap gp_hash_table
typedef pair<int,int> pii;
const int mod=1E9+7;
const int inf=2E18;
int fpw(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

template <class T1,class T2> 
struct tr1::hash<pair<T1,T2> >{size_t operator()(pair<T1,T2>x) const{tr1::hash<T1>H1;tr1::hash<T2>H2;return H1(x.fi)^H2(x.se);}};

template<class T,class TT=null_type>
using rbt=tree<T,TT,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

#ifdef ONLINE_JUDGE
#define bug(...) void(0)
#else 
template<typename...A>void bug(const A&...a){cout<<"DEBUG";((cout<<' '<<a),...);cout<<endl;}
#endif
template<typename...A>void out(const A&...a){bool f=1;((cout<<(f?(f=0,""):" ")<<a),...);cout<<'\n';}

struct p
{
    int x,y;
    int id;
};

bool cmp(p &a,p &b)
{
    if(a.x!=b.x)return a.x<b.x;
    if(a.y!=b.y)return a.y<b.y;
    return a.id<b.id;
}
bool cmp2(p &a,p &b)
{
    if(a.y!=b.y)return a.y<b.y;
    if(a.x!=b.x)return a.x<b.x;
    return a.id<b.id;
}
void solve()
{
    int n;cin>>n;
    vector<p>a(n);
    for(int i=0;i<n;i++)
    {
        cin>>a[i].x>>a[i].y;
        a[i].id=i+1;
    }
    vector<bool>l(n+1,false);

    sort(a.begin(),a.end(),cmp);
    for(int i=0;i<n/2;i++)
    {
        l[a[i].id]=true;
    }

    vector<p>b(a);
    sort(b.begin(),b.end(),cmp2);

    vector<bool>r(n+1,false);

    for(int i=0;i<n/2;i++)
    {
        r[b[i].id]=true;
    }

    vector<int>A,B,C,D;
    for(int i=1;i<=n;i++)
    {
        if(l[i]&&r[i])A.pb(i);
        else if(l[i]&&!r[i])B.pb(i);
        else if(!l[i]&&r[i])C.pb(i);
        else if(!l[i]&&!r[i])D.pb(i);
    }

    int c1=SZ(A);
    int c2=SZ(B);
    for(int i=0;i<c1;i++)
    {
        cout<<A[i]<<' '<<D[i]<<'\n';
    }

    for(int i=0;i<c2;i++)
    {
        cout<<B[i]<<' '<<C[i]<<'\n';
    }
}
signed main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);
    int tt;cin>>tt;while(tt--)solve();
    return 0;
}




// #include <iostream>
// #include <vector>
// #include <algorithm>
// using namespace std;

// struct Point {
//     long long x, y;
//     int id;
// };

// int main() {
//     ios::sync_with_stdio(false);
//     cin.tie(nullptr);

//     int t;
//     cin >> t;
//     while (t--) {
//         int n;
//         cin >> n;
//         vector<Point> points(n);
//         for (int i = 0; i < n; i++) {
//             cin >> points[i].x >> points[i].y;
//             points[i].id = i + 1;
//         }

//         vector<bool> isLeft(n + 1, false);
//         sort(points.begin(), points.end(), [](const Point& a, const Point& b) {
//             if (a.x != b.x) {
//                 return a.x < b.x;
//             }
//             if (a.y != b.y) {
//                 return a.y < b.y;
//             }
//             return a.id < b.id;
//         });

//         for (int i = 0; i < n / 2; i++) {
//             isLeft[points[i].id] = true;
//         }

//         vector<Point> pointsY = points;
//         sort(pointsY.begin(), pointsY.end(), [](const Point& a, const Point& b) {
//             if (a.y != b.y) {
//                 return a.y < b.y;
//             }
//             if (a.x != b.x) {
//                 return a.x < b.x;
//             }
//             return a.id < b.id;
//         });

//         vector<bool> isDown(n + 1, false);
//         for (int i = 0; i < n / 2; i++) {
//             isDown[pointsY[i].id] = true;
//         }

//         vector<int> LD, LU, RD, RU;
//         for (int i = 1; i <= n; i++) {
//             if (isLeft[i] && isDown[i]) {
//                 LD.push_back(i);
//             } else if (isLeft[i] && !isDown[i]) {
//                 LU.push_back(i);
//             } else if (!isLeft[i] && isDown[i]) {
//                 RD.push_back(i);
//             } else if (!isLeft[i] && !isDown[i]) {
//                 RU.push_back(i);
//             }
//         }

//         int k = LD.size();
//         for (int i = 0; i < k; i++) {
//             cout << LD[i] << " " << RU[i] << "\n";
//         }
//         int m = LU.size();
//         for (int i = 0; i < m; i++) {
//             cout << LU[i] << " " << RD[i] << "\n";
//         }
//     }
//     return 0;
// }